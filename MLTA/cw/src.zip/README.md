# Launching:
export LD_LIBRARY_PATH=/usr/local/lib
g++ main.cpp print.cpp -lbdd
