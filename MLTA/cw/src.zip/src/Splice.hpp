#pragma once

namespace mlta
{

enum class Splice : int
{
    kVertical,
    kHorizontal,
    kNone
};

} // namespace mlta
